# Notice

안내 박스입니다. `blue-tint` 배경, 8px `rail-blue` 점, 제목 14px/700 `rail-blue-deep`, 본문 12px `rail-blue-mid`.

화면당 하나의 서비스 설명(알림톡, 연계 교통 합계)에 씁니다. 오류에는 쓰지 말고 인라인 `warn-text`를 씁니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
