# Radio

20px 원형 라디오입니다(원본 `radio()`). 꺼짐은 2px `radio-line`, 켜짐은 `select-blue` 채움에 3.5px 흰 안쪽 테두리.

모양만 담당합니다. 클릭과 `role="radio"`는 ChoiceRow나 감싸는 행 버튼이 맡습니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
