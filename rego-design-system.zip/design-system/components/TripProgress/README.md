# TripProgress

이동 중 진행 막대입니다. 모노 출발·도착, 6px `surface-muted` 트랙, `rail-blue` 채움, 3px 흰 테두리의 `accent-rust` 손잡이, 12px 상태 문구.

이동 중 화면의 Card 안에 넣고, 위에는 남은 시간을 `accent-rust`로 강조한 page-title을 둡니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
