// REGO — component types (documentation). Global: window.REGO. Requires React 18 + ReactDOM 18 globals.
import * as React from 'react';

/** The RG mark: italic R (`rail-blue`) + G (`go-yellow`) with three speed lines, plus tagline. */
export interface LogoProps { withTagline?: boolean; tagline?: string; className?: string }
export declare function Logo(props: LogoProps): React.ReactElement;

export interface ButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  /** primary = rail-blue CTA; secondary = 이전/나중에; outline = 조건 다시 고르기; dark = on paper, strong; inverse = white on rail-blue; kakao = Kakao login; text = underlined link-button */
  variant?: 'primary' | 'secondary' | 'outline' | 'dark' | 'inverse' | 'kakao' | 'text';
  /** lg = 56px (default), md = 52px */
  size?: 'lg' | 'md';
  /** pill (default, radius-pill) or rect (radius-md; login screen) */
  shape?: 'pill' | 'rect';
  block?: boolean;
  /** Material Symbols Outlined ligature name, e.g. "chat_bubble" */
  icon?: string;
}
export declare function Button(props: ButtonProps): React.ReactElement;

export interface IconButtonProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  icon: string;
  /** soft = stepper ±; ghost = home in a screen header; glass = floating over content; reset = calendar reset */
  tone?: 'soft' | 'ghost' | 'glass' | 'reset';
  /** Accessible name (required: icons carry no text) */
  label: string;
}
export declare function IconButton(props: IconButtonProps): React.ReactElement;

export interface ChipProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  selected?: boolean;
  /** md = 44px taste/condition chip (select-blue when on); sm = 34px filter chip */
  size?: 'md' | 'sm';
  /** sm only: ink = tabs, green = added cities */
  tone?: 'ink' | 'green';
}
export declare function Chip(props: ChipProps): React.ReactElement;

export interface OptionTileProps extends React.ButtonHTMLAttributes<HTMLButtonElement> { selected?: boolean; title: string; sub?: string }
export declare function OptionTile(props: OptionTileProps): React.ReactElement;

export interface RadioProps { checked?: boolean; className?: string }
export declare function Radio(props: RadioProps): React.ReactElement;

export interface ChoiceRowProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  selected?: boolean;
  /** 버스 | 셔틀 | 택시 | 도보 | 지하철 — picks the mode-* badge colour */
  mode?: string;
  name: string;
  note?: string;
  duration?: string;
  fare?: string;
}
export declare function ChoiceRow(props: ChoiceRowProps): React.ReactElement;

export interface SwitchProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  on?: boolean;
  /** Larger 56×34 switch for the rail-blue completion screen (switch-mint when on) */
  onBlue?: boolean;
  label: string;
}
export declare function Switch(props: SwitchProps): React.ReactElement;

export interface BadgeProps {
  /** neutral = post tag; info = lead role; transit = summary on course card; mode = transit mode (children = mode name); voucher; match = on photos; done = album entry recorded */
  tone?: 'neutral' | 'info' | 'transit' | 'mode' | 'voucher' | 'match' | 'done';
  /** match only: top-ranked course uses select-blue */
  best?: boolean;
  children: React.ReactNode;
  className?: string;
}
export declare function Badge(props: BadgeProps): React.ReactElement;

export interface CardProps extends React.HTMLAttributes<HTMLDivElement> { tone?: 'light' | 'dark'; flush?: boolean }
export declare function Card(props: CardProps): React.ReactElement;

export interface CourseCardProps extends React.ButtonHTMLAttributes<HTMLButtonElement> {
  image?: string; match?: number; best?: boolean; route?: string; title: string; why?: string; transit?: string; meta?: string; price: string;
}
export declare function CourseCard(props: CourseCardProps): React.ReactElement;

export interface StepperProps { value?: number; defaultValue?: number; min?: number; max?: number; onChange?: (n: number) => void; className?: string }
export declare function Stepper(props: StepperProps): React.ReactElement;

export interface NoticeProps { title: string; children?: React.ReactNode; className?: string }
export declare function Notice(props: NoticeProps): React.ReactElement;

export interface TripProgressProps { from: string; to: string; percent: number; children?: React.ReactNode; className?: string }
export declare function TripProgress(props: TripProgressProps): React.ReactElement;
