# IconButton

글자 없이 아이콘만 있는 둥근 버튼입니다. 44px(`size-touch`), 헤더용은 40px.

- **soft** — `surface-sunken` 배경에 `rail-blue` 아이콘, 호버 `blue-tint`(인원 ±, 북마크).
- **ghost** — 모든 화면 왼쪽 위 홈 버튼.
- **glass** — `glass` + 8px 블러, 사진·콘텐츠 위에 떠 있는 버튼(메뉴, 사진 히어로 위 홈).
- **reset** — `berry-tint` / `berry`, 달력 다시 선택 전용.

`label`(aria-label)은 꼭 넘깁니다. 아이콘은 Material Symbols Outlined 굵기 300입니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
