# Button

알약형 CTA로 높이 56px(`size-cta`, 반경 28), 라벨은 `button`(16px/700)입니다.

- **primary** — `rail-blue`, 호버 `rail-blue-deep`. 화면당 하나, 아래쪽에 전체 폭 또는 보조 버튼 옆 `flex:1`.
- **secondary** — `surface-muted` / `ink-2`(“이전”, “나중에”). 주요 버튼 왼쪽, 좌우 여백 22px.
- **outline** — 52px, 1px `line-strong`, `ink-3` 라벨(“조건 다시 고르기”).
- **dark** — 종이 배경 위 `ink` 버튼. 예약이 아닌 강한 행동용(“지금 발송된 알림톡 보기”).
- **inverse** — `rail-blue` 예약 완료 화면 위 흰 버튼, `rail-blue-deep` 라벨.
- **kakao** / `shape="rect"` — 로그인 화면 전용(radius-md).
- **disabled** — `line-strong` 배경, `text-subtle` 라벨. 라벨은 무엇이 부족한지 말합니다(“2개 이상 골라주세요”).

사용하는 쪽에서 라벨(한국어 동사구), `onClick`, 필요하면 `icon`(Material Symbols 이름)을 넘깁니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
