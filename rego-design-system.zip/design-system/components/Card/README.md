# Card

기본 컨테이너입니다. `surface`, radius-md, 여백 20px, `shadow-card`, 안쪽 간격 12px.

- 26px 좌우 여백 안쪽 `surface-paper` 위에 놓습니다. 카드 안 구역은 카드를 겹치지 말고 1px `line-soft`로 나눕니다.
- `tone="dark"`(`surface-ink`, 흰 글자, `sand` 포인트)는 실시간 정보용입니다.
- 행마다 자체 여백이 있는 목록 카드는 `flush`.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
