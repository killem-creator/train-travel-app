REGO(Rail + Go, “레일 위에서, 바로 간다”)는 기차여행 앱입니다. 흐름은 성향 → 조건 → 추천 코스 → 연계 교통 → 예약 → 위치 기반 알림톡 → 여행 사진첩입니다. 정한 방향은 **여행 사진집**입니다. 여백을 넓게 두고, 사진이 화면을 끌고 가며, 타이포는 명조로 조용하게 둡니다.

## 콘텐츠 원칙

- **언어:** 한국어가 기본입니다. 영문은 모노 아이브로와 코드에만 씁니다(STEP 1 / 3, KTX 851, TR-4820-1193, RAIL + GO).
- **말투:** 따뜻하고 짧은 해요체입니다. 앱은 스스로를 “저희”라고 부르고, 여행자를 “당신”이라고 부르지 않습니다: “조건만 맞춰주시면 나머지는 저희가 짭니다”, “예약이 끝났어요. 이제 짐만 챙기세요”.
- **제목**은 대화하듯 쓰고 `<br>`로 2–3줄로 끊습니다: “다녀온 곳마다 / 사진 한 장과 한 문장”. 핵심 숫자는 `accent-rust`로 강조합니다: “정동진까지 **42분**”.
- **버튼**은 다음 단계를 말하는 동사구입니다: “여행 추천 받기”, “연계 교통 고르기”, “예약으로”. 비활성 CTA는 무엇이 부족한지 말합니다: “2개 이상 골라주세요”.
- **메타 정보**는 ` · `로 잇습니다: “서울 → 정동진 · KTX 2시간 12분”. 노선은 `→`, 금액은 `289,000원`, 시각은 `06:01`, 소요시간은 `18분`으로 씁니다.
- 이모지는 쓰지 않습니다. 문구 안의 기호는 인라인 경고(`warn-text`)의 ⚠ 하나뿐입니다.

## 색상

- 화면 배경은 `surface-paper`, 내용 묶음은 `shadow-card`가 있는 `surface` 카드입니다. 로그인·홈 히어로는 `sky` 위에 `train-hero` 일러스트를 두고 `surface-paper`로 자연스럽게 이어집니다.
- **`rail-blue`는 브랜드이자 주요 행동 색입니다:** 주요 CTA(호버 `rail-blue-deep`), 링크, 교통편 요금, 진행 막대, 예약 완료 화면. 주요 CTA는 화면당 하나입니다.
- **`select-blue`는 “고른 것”을 뜻합니다:** 선택된 칩·타일·라디오·옵션 행, 최고 매칭 배지. 선택 안 된 컨트롤은 `surface` 배경에 `select-line` 테두리입니다.
- **`accent-rust`는 편집 포인트 색입니다:** 번호, 구간 번호(LEG 1), 실시간·GPS 상태, 남은 시간 숫자, 글머리 점. 아껴 쓰고 버튼 배경으로는 쓰지 않습니다.
- **`success-green`**은 확정·추가·켜짐을 뜻합니다(스위치, 체크박스, 담은 도시·열차, 실시간 접속, 1인당 금액).
- 글자: 제목과 값은 `ink`, 문단은 `text-muted`, 메타는 `text-subtle`. `text-faint`와 `text-placeholder`는 원본에서 AA 미달(2.5–2.9:1)이므로 모노 아이브로, 카운터, 약관 문구에만 씁니다.
- 어두운 장면: 실시간 카드와 완성된 사진첩은 `surface-ink`에 `sand` 포인트. 알림톡 미리보기는 `surface-message`에 `message-ink`.
- 교통수단 색은 고정입니다: `mode-bus`, `mode-shuttle`, `mode-taxi`, `mode-walk`, `mode-subway`.
- `go-yellow`는 로고의 G에만, `kakao-yellow`는 카카오 로그인 버튼에만 씁니다.

## 타이포그래피

- Google Fonts 3종: 제목은 **Noto Serif KR**(`serif`, 500/700/900), UI와 본문은 **Noto Sans KR**(`sans`, 400/500/700/900), 아이브로·시각·거리·코드는 **IBM Plex Mono**(`mono`, 400/500).
- 화면 제목: `screen-title` / `page-title`(세리프 900, 30px 이상은 −0.02em). 카드·모달 제목: `card-title`.
- 세리프 제목 위에는 항상 `text-faint` 색의 모노 `eyebrow`를 둡니다(`sky` 위에서는 `hero-label`).
- 본문은 `text-muted` 색의 `body`(14/1.7) 또는 `body-sm`(13/1.65). 카드 안 섹션 라벨은 `label`(15/700 `ink`).
- 가격과 수치는 산세리프 900: `price`, `price-lg`, `stat`. 줄을 맞춰야 하는 시각·숫자는 `data` / `time-lg`(모노).

## 간격, 모양, 그림자

- 디자인 프레임 402×874(`size-frame`). 좌우 여백은 항상 `space-26`, 화면은 `space-screen-top`(70px) 아래에서 시작합니다.
- 섹션 사이는 `space-22`–`space-26`, 항목 사이는 `space-8`–`space-12`.
- 카드, 입력창, 타일, 옵션 행은 기본 `radius-md`(10px). 버튼과 칩은 알약형(`radius-pill`, 56px CTA = 28px). 사진 인화 카드와 스탬프는 `radius-xs`(4px).
- 터치 영역은 최소 `size-touch`(44px), CTA는 `size-cta`(56px).
- 그림자는 가볍게: 기본 `shadow-card`, 호버 `shadow-hover` / `shadow-lift`, 옵션 선택 시 파란 기운의 `shadow-selected`. 카드 안 구분선은 1px `line-soft`, 테두리는 1px `line`.
- 하단 고정 바: 93% 흰색 + 12px 배경 블러, 위 테두리 `line-soft`, `price-lg` 금액 아래 전체 폭 주요 CTA.
- 모션은 작고 기능적으로: 선택 0.16s ease, 스위치 0.18s, 실시간 상태는 1.6s 깜빡이는 점, 시즌 광고 띠는 60s 흐름(호버 시 멈춤).

## 이미지

- 사진이 주인공입니다. 코스 사진은 가장자리까지 채우고(카드 190px, 상세 히어로 320–340px), 흰 글자가 읽히도록 아래쪽을 투명 → `ink` 62–82% 그라디언트로 덮습니다.
- `train-hero` 일러스트(다리 위 KTX, 벚꽃, 하늘)는 `sky` 위 홈·로그인 배경입니다.
- 사진 위 라벨은 `photo-badge`(`rgba(26,26,24,.72)`)에 흰 글자, 둥근 공유·찜 버튼은 `scrim`.
- 사진첩 항목은 사진 한 장과 한 문장을 담은 흰 “인화본”입니다(`radius-xs`, 1px `surface-photo` 테두리).

## 아이콘

- **Material Symbols Outlined**, 굵기 300. Google Fonts에서 불러와 합자(ligature)로 씁니다(`<span class="rg-icon">home</span>`). 크기 16–24px, 헤더는 22px.
- 사용 중인 아이콘: home, menu, close, add, remove, check, refresh, calendar_month, edit_calendar, chevron_right, ios_share, favorite, bookmark, storefront, directions, directions_bus, chat_bubble, map, my_location, tune, recommend, receipt_long, task_alt, forum, edit_note, photo_album, campaign, confirmation_number, group, restaurant, wb_twilight, south, flag.
- 아이콘 색은 옆 글자를 따르고, 행 끝 화살표는 `icon-quiet`. 이모지나 자체 아이콘 파일은 쓰지 않습니다.

## 로고

- 로고는 글자로 만든 마크입니다: Noto Sans KR 900 이탤릭 **R**(`rail-blue`) + **G**(`go-yellow`), 앞에 점점 짧아지는 `rail-blue` 속도선 3개, 옆에 태그라인과 “RAIL + GO”. `Logo` 컴포넌트를 쓰세요. 저장소에 로고 이미지 파일은 없습니다.

## 컴포넌트

`REGO.Button`, `IconButton`, `Chip`, `OptionTile`, `Radio`, `ChoiceRow`, `Switch`, `Badge`, `Card`, `CourseCard`, `Stepper`, `Notice`, `TripProgress`, `Logo` — 각 카드에 상태별 모습과 쓰임이 있습니다. 포커스: 모든 인터랙티브 컨트롤에 2px 실선 `rail-blue-deep` 외곽선, 2px 띄움(`surface` 위 7.0:1).

## 전체 객체

`rego-design-system.json`은 이 시스템 전체(색상, 타이포, 간격, 반경, 그림자, 크기, 컴포넌트와 속성, 이미지, 아이콘)를 이름으로 바로 찾을 수 있는 하나의 객체로 묶은 파일입니다. 예: `color["rail-blue"].value`, `components.Button.props`. 화면으로는 Brand 그룹의 **ObjectView** 카드에서 트리로 펼쳐 보고, 검색하고, 키를 눌러 값을(Shift+클릭은 경로를) 복사할 수 있습니다. 값의 원본은 `tokens.json`이며, 토큰을 바꾸면 이 파일도 다시 만들어야 합니다.

## 동기화되지 않은 것

- 저장소(`killem-creator/train-travel-app`, main@86fd46a)에는 번들된 프로토타입 페이지 `REGO 기차여행 앱.html` 하나뿐이고, 토큰 파일·CSS 변수·컴포넌트 라이브러리가 없습니다. 여기 있는 모든 값은 그 페이지의 인라인 스타일과 `chip()` / `tile()` / `radio()` 헬퍼에서 그대로 가져와 용도에 맞게 이름 붙인 것입니다.
- 컴포넌트는 그 인라인 스타일을 보고 **직접 작성**했습니다(실행할 빌드가 없음). 화면 단위 구성(달력, 일정 타임라인, 알림톡 말풍선, 사진첩 편집, 패스 일정 짜기, 동행 목록, 전체 메뉴 시트)은 아직 컴포넌트가 아닙니다.
- 폰트는 Google Fonts에서 불러옵니다(Noto Sans KR, Noto Serif KR, IBM Plex Mono, Material Symbols Outlined). 프로토타입에 들어 있던 서브셋 폰트 파일은 복사하지 않았습니다.
- 프로토타입 꾸밈 요소로 보고 제외: `#E7E5DF` 책상 배경, 반경 2px 옆 패널, 스타터 iOS 기기 프레임(`ios-frame.jsx`)과 image-slot 도우미.
