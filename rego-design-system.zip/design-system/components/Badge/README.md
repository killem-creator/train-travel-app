# Badge

누를 수 없는 작은 라벨입니다. radius-tag(6px), 10–11px 굵게.

- **neutral** `surface-sunken`/`text-muted` — 게시글 분류, 작성자 태그.
- **info** `blue-tint`/`rail-blue-deep` — 대표 역할, 첫 출발 시간.
- **transit** `blue-tint-3`/`rail-blue` — 코스 카드의 연계 교통 요약.
- **mode** — `mode-bus` / `mode-shuttle` / `mode-taxi` / `mode-walk` / `mode-subway` 위 흰 글자. 한국어 교통수단 이름으로 색이 정해집니다.
- **voucher** — 모노 글자, `rust-tint` 알약에 `rust-line` 테두리.
- **match** — 사진 위 `photo-badge`. 최고 매칭은 `best`로 `select-blue`.
- **done** — 사진첩 기록 완료(알약형).

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
