/* @ds-bundle: {"format":4,"namespace":"REGO","components":[{"name":"Logo"},{"name":"Button"},{"name":"IconButton"},{"name":"Chip"},{"name":"OptionTile"},{"name":"Radio"},{"name":"ChoiceRow"},{"name":"Switch"},{"name":"Badge"},{"name":"Card"},{"name":"CourseCard"},{"name":"Stepper"},{"name":"Notice"},{"name":"TripProgress"}]} */
(function () {
  'use strict';
  var React = window.React;
  var h = React.createElement;
  function cx() { return Array.prototype.filter.call(arguments, Boolean).join(' '); }
  function rest(props, omit) { var o = {}; for (var k in props) if (omit.indexOf(k) < 0) o[k] = props[k]; return o; }

  function Icon(p) { return h('span', { className: 'rg-icon', 'aria-hidden': 'true', style: { fontSize: p.size || 22 } }, p.name); }

  function Logo(p) {
    p = p || {};
    var showText = p.withTagline !== false;
    return h('span', { className: cx('rg-logo', p.className), role: 'img', 'aria-label': 'REGO — Rail + Go' },
      h('span', { className: 'rg-logo__mark' },
        h('span', { className: 'rg-logo__line rg-logo__l1' }),
        h('span', { className: 'rg-logo__line rg-logo__l2' }),
        h('span', { className: 'rg-logo__line rg-logo__l3' }),
        h('span', { className: 'rg-logo__r' }, 'R'),
        h('span', { className: 'rg-logo__g' }, 'G')),
      showText ? h('span', { className: 'rg-logo__text' },
        h('span', { className: 'rg-logo__tag' }, p.tagline || '레일 위에서, 바로 간다'),
        h('span', { className: 'rg-logo__sub' }, 'RAIL + GO')) : null);
  }

  function Button(p) {
    var v = p.variant || 'primary';
    return h('button', Object.assign({ type: 'button' }, rest(p, ['variant', 'size', 'shape', 'block', 'icon', 'className', 'children']), {
      className: cx('rg-btn', 'rg-btn--' + v, p.size === 'md' && 'rg-btn--md', p.shape === 'rect' && 'rg-btn--rect', p.block && 'rg-btn--block', p.className)
    }), p.icon ? h(Icon, { name: p.icon, size: 20 }) : null, p.children);
  }

  function IconButton(p) {
    return h('button', Object.assign({ type: 'button' }, rest(p, ['icon', 'tone', 'className', 'label']), {
      className: cx('rg-iconbtn', 'rg-iconbtn--' + (p.tone || 'soft'), p.className), 'aria-label': p.label
    }), h(Icon, { name: p.icon, size: p.tone === 'reset' ? 20 : 22 }));
  }

  function Chip(p) {
    return h('button', Object.assign({ type: 'button' }, rest(p, ['selected', 'size', 'tone', 'className', 'children']), {
      'aria-pressed': p.selected ? 'true' : 'false',
      className: cx('rg-chip', p.size === 'sm' && 'rg-chip--sm', p.size === 'sm' && 'rg-chip--' + (p.tone || 'ink'), p.className)
    }), p.children);
  }

  function OptionTile(p) {
    return h('button', Object.assign({ type: 'button' }, rest(p, ['selected', 'title', 'sub', 'className']), {
      'aria-pressed': p.selected ? 'true' : 'false', className: cx('rg-tile', p.className)
    }), h('span', { className: 'rg-tile__title' }, p.title), p.sub ? h('span', { className: 'rg-tile__sub' }, p.sub) : null);
  }

  function Radio(p) {
    return h('span', { role: 'radio', 'aria-checked': p.checked ? 'true' : 'false', className: cx('rg-radio', p.className) });
  }

  var MODE_TOKEN = { '버스': 'mode-bus', '셔틀': 'mode-shuttle', '택시': 'mode-taxi', '도보': 'mode-walk', '지하철': 'mode-subway' };

  function Badge(p) {
    var tone = p.tone || 'neutral';
    var style = null;
    if (tone === 'mode') style = { background: 'var(--' + (MODE_TOKEN[p.children] || 'ink') + ')' };
    return h('span', { className: cx('rg-badge', tone !== 'neutral' && 'rg-badge--' + tone, p.best && 'rg-badge--best', p.className), style: style }, p.children);
  }

  function ChoiceRow(p) {
    return h('button', Object.assign({ type: 'button', role: 'radio' }, rest(p, ['selected', 'mode', 'name', 'note', 'duration', 'fare', 'className']), {
      'aria-checked': p.selected ? 'true' : 'false', className: cx('rg-choice', p.className)
    }),
      h(Radio, { checked: p.selected }),
      h('span', { className: 'rg-choice__body' },
        h('span', { className: 'rg-choice__head' }, p.mode ? h(Badge, { tone: 'mode' }, p.mode) : null, h('span', { className: 'rg-choice__name' }, p.name)),
        p.note ? h('span', { className: 'rg-choice__note' }, p.note) : null),
      (p.duration || p.fare) ? h('span', { className: 'rg-choice__end' },
        p.duration ? h('span', { className: 'rg-choice__dur' }, p.duration) : null,
        p.fare ? h('span', { className: 'rg-choice__fare' }, p.fare) : null) : null);
  }

  function Switch(p) {
    return h('button', Object.assign({ type: 'button', role: 'switch' }, rest(p, ['on', 'onBlue', 'className', 'label']), {
      'aria-checked': p.on ? 'true' : 'false', 'aria-label': p.label, className: cx('rg-switch', p.onBlue && 'rg-switch--on-blue', p.className)
    }), h('span', { className: 'rg-switch__knob' }));
  }

  function Card(p) {
    return h('div', Object.assign({}, rest(p, ['tone', 'flush', 'className', 'children']), {
      className: cx('rg-card', p.tone === 'dark' && 'rg-card--dark', p.flush && 'rg-card--flush', p.className)
    }), p.children);
  }

  function CourseCard(p) {
    return h('button', Object.assign({ type: 'button' }, rest(p, ['image', 'match', 'best', 'route', 'title', 'why', 'transit', 'meta', 'price', 'className']), { className: cx('rg-course', p.className) }),
      h('div', { className: 'rg-course__thumb', style: p.image ? { backgroundImage: 'url(' + p.image + ')' } : null },
        p.match != null ? h('span', { className: 'rg-course__match' }, h(Badge, { tone: 'match', best: p.best }, '매칭 ' + p.match + '%')) : null),
      h('div', { className: 'rg-course__body' },
        p.route ? h('div', { className: 'rg-course__route' }, p.route) : null,
        h('div', { className: 'rg-course__title' }, p.title),
        p.why ? h('div', { className: 'rg-course__why' }, p.why) : null,
        p.transit ? h('div', null, h(Badge, { tone: 'transit' }, p.transit)) : null,
        h('div', { className: 'rg-course__foot' }, h('span', { className: 'rg-course__meta' }, p.meta), h('span', { className: 'rg-course__price' }, p.price))));
  }

  function Stepper(p) {
    var min = p.min == null ? 1 : p.min, max = p.max == null ? 8 : p.max;
    var st = React.useState(p.defaultValue == null ? min : p.defaultValue);
    var val = p.value == null ? st[0] : p.value;
    function set(n) { n = Math.max(min, Math.min(max, n)); st[1](n); if (p.onChange) p.onChange(n); }
    return h('div', { className: cx('rg-stepper', p.className) },
      h(IconButton, { icon: 'remove', label: '줄이기', onClick: function () { set(val - 1); }, disabled: val <= min }),
      h('div', { className: 'rg-stepper__value', 'aria-live': 'polite' }, val),
      h(IconButton, { icon: 'add', label: '늘리기', onClick: function () { set(val + 1); }, disabled: val >= max }));
  }

  function Notice(p) {
    return h('div', { className: cx('rg-notice', p.className) },
      h('span', { className: 'rg-notice__dot' }),
      h('div', null, h('div', { className: 'rg-notice__title' }, p.title), p.children ? h('div', { className: 'rg-notice__text' }, p.children) : null));
  }

  function TripProgress(p) {
    var pct = Math.max(0, Math.min(100, p.percent || 0)) + '%';
    return h('div', { className: cx('rg-progress', p.className) },
      h('div', { className: 'rg-progress__ends' }, h('span', null, p.from), h('span', null, p.to)),
      h('div', { className: 'rg-progress__track', role: 'progressbar', 'aria-valuenow': p.percent, 'aria-valuemin': 0, 'aria-valuemax': 100 },
        h('span', { className: 'rg-progress__fill', style: { width: pct } }),
        h('span', { className: 'rg-progress__knob', style: { left: pct } })),
      p.children ? h('div', { className: 'rg-progress__note' }, p.children) : null);
  }

  window.REGO = { Logo: Logo, Button: Button, IconButton: IconButton, Chip: Chip, OptionTile: OptionTile, Radio: Radio, ChoiceRow: ChoiceRow, Switch: Switch, Badge: Badge, Card: Card, CourseCard: CourseCard, Stepper: Stepper, Notice: Notice, TripProgress: TripProgress, Icon: Icon };
})();
