# Logo

RG 마크입니다. 이탤릭 **R**(`rail-blue`)과 **G**(`go-yellow`, Rail + Go) 앞에 점점 짧아지는 `rail-blue` 속도선 3개가 있고, 옆에 태그라인 “레일 위에서, 바로 간다”와 모노 보조 문구 RAIL + GO가 붙습니다.

- 로그인·홈 히어로 위쪽, `sky` 또는 `surface-paper` 위에 씁니다.
- 파일이 아니라 글자(Noto Sans KR 900 이탤릭)로 만든 로고입니다. 저장소에 로고 이미지가 없으니 그림으로 다시 그리지 말고 이 컴포넌트를 쓰세요.
- 마크만 필요하면 `withTagline={false}`.
- `go-yellow`를 다른 곳의 글자색으로 쓰지 않습니다(`sky` 위 1.6:1).

속성: `withTagline`, `tagline`.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
