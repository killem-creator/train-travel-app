# ChoiceRow

연계 교통 구간과 결제수단에 쓰는 선택 행입니다. 라디오, 교통수단 배지 + 이름(14px/700), 설명(12px `text-muted`), 오른쪽에 모노 소요시간과 `rail-blue` 요금이 있습니다.

- 기본: `surface`, `shadow-card`, 투명한 1.5px 테두리. 선택: `select-blue` 테두리 + `shadow-selected`.
- 8px 간격으로 쌓고 구간마다 하나만 선택합니다. 고른 요금은 예약 금액에 합산됩니다.

사용하는 쪽에서 `mode`, `name`, `note`, `duration`, `fare`, `selected`, `onClick`을 넘깁니다.

_`REGO 기차여행 앱.html`을 보고 직접 작성했습니다. 저장소에 컴포넌트 라이브러리는 없습니다._
